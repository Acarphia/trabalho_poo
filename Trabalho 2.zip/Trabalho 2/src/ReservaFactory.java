public abstract class ReservaFactory {
    public abstract Reserva criarReserva(int codigo, String cliente, Object... dados);
}
